package math;

public interface IPolynomial {
	public double getY(double x);

	public int getGrade();
}

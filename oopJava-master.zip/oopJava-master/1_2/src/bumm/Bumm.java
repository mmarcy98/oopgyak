package bumm;

public class Bumm {
	public static void main(String[] args) {
		
		for(int i=10;i>0;i--) {
			System.out.println(i);
		}
			
		System.out.println("Bumm!");
	}	
}
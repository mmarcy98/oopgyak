package kivetel;

public class primeException extends Exception {
	public primeException(String a) {
		super(a);
	}	
}